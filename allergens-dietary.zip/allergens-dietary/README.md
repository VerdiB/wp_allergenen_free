# Allergens Dietary Ictoria - V0.1.0.0

## Fixes and changes
- First release
- function fixes

### Performance

### General

## Technical Updates

## added feature


# Allergens Dietary Ictoria - V0.2.0.0

## Fixes and changes
- function fixes (Was deleted later on)

### Performance

### General
- Documentary changes

## Technical Updates

## added feature


# Allergens Dietary Ictoria - V0.3.0.0

## Fixes and changes

### Performance

### General
- Documentary changes

## Technical Updates

## added feature
- A form to fill in your licence key


# Allergens Dietary Ictoria - V0.4.0.0

## Fixes and changes

### Performance

### General

## Technical Updates
- Automatic updates

## added feature
- The option to update allergens for premium users
- The option to add diets for premium users
- The option to add allergens for premium users


# Allergens Dietary Ictoria - V0.16.5.1

## Fixes and changes
- Description plugin translation fix
- 'allergen already exists' notification for adding allergens that already exist instead of an error
- Made it visible when an active allergen is connected to an product
- removed functions.php and placed it back in other files exept for the unused functions 

### Performance

### General

## Technical Updates

## added feature
- Default allergens 
- Tabs to navigate through the submenu's of the plugin
- A submenu that shows the custom and default allergens that have been added
- An option to change the status of an allergen (active or inactive)
- Allergen title visible when hovering over it
- A submenu with info about the plugin
- A standard image for an allergen without an image selected
- UK translations
- UX/conform front-end
- Made the plugin wordpress theme friendly


# Allergens Dietary Ictoria - V0.17.1.1

## Fixes and changes
- Made a show allergens table update after updating an allergen directly visible instead of doing a refresh (bug fix)

### Performance

### General

## Technical Updates

## added feature


# Allergens Dietary Ictoria - V0.18.5.1

## Fixes and changes
- Add allergen UX conform
- Allergen images standard height and width
- Shop filter UX conform
- updated translations
- deleted standard menu subpage

### Performance

### General
- Documentary changes

## Technical Updates

## added feature

